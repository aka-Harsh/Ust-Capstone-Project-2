package com.example.parkingbooking_service.repository;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.parkingbooking_service.repository.entity.ParkingBookingEntity;

import feign.Param;

@Repository
public interface ParkingBookingRepository extends JpaRepository<ParkingBookingEntity, Integer> {
	
	List<ParkingBookingEntity> findByParkingIdAndParkingBookingDate(int parkingId, LocalDate parkingBookingDate);
	
	@Query("SELECT pb FROM ParkingBookingEntity pb WHERE pb.ParkingDto.parkingBuilding = :building AND pb.ParkingDto.parkingFloor = :floor " +
	           "AND pb.parkingBookingDate = :bookingDate " +
	           "AND ((pb.startTime BETWEEN :startTime AND :endTime) OR (pb.endTime BETWEEN :startTime AND :endTime) OR " +
	           "(pb.startTime <= :startTime AND pb.endTime >= :endTime))")
	List<ParkingBookingEntity> findBookedSlots(@Param("bookingDate") LocalDate parkingBookingDate, 
	                                         @Param("startTime") LocalTime startTime,
	                                         @Param("endTime") LocalTime endTime,
	                                         @Param("building") String building,
	                                         @Param("floor") String floor);
 
}
