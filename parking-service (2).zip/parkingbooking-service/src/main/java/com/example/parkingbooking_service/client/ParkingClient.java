package com.example.parkingbooking_service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.parkingbooking_service.dto.ParkingDto;

@FeignClient(name = "parking-service", url = "http://localhost:3333/api/parkings")
public interface ParkingClient {
	
	@GetMapping("{parkingId}")
    ParkingDto getParkingById(@PathVariable int parkingId);
	
	@PutMapping
	ParkingDto updateParkingSlot(@RequestBody ParkingDto parking);
	
	@GetMapping("/building/{building}/floor/{floor}")
    List<ParkingDto> getParkingByBuildingAndFloor(@PathVariable String building, @PathVariable String floor);
}

