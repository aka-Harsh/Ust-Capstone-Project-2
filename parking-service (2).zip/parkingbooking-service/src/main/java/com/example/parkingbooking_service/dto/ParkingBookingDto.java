package com.example.parkingbooking_service.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class ParkingBookingDto {

	private int parkingBookingId;
    private int userId;
    private int parkingId;
    private LocalDate parkingBookingDate;
    private LocalTime startTime;
    private LocalTime endTime;
	
}
